<template>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <h2>Create an Account</h2>
                <div class="form-group">
                <label for="first_name">First Name</label>
                <input type="text" class="form-control" name="fname" id="fname" placeholder="First Name" v-model="fname"/>
                </div>
            </div>
        </div>
    </div>
</template>

<script>

</script>